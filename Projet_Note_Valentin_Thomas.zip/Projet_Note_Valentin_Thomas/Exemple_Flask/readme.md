API Flask

cf Projet_API_Flask_NLP.odt dans ce meme repertoire